/*
  PID.cpp - Library for creating a PID controller.
  Created by All Parts Combined, 2021.
  Released into the public domain.
*/

#include "Arduino.h"
#include "PID.h"

PID::PID(double t)
	: target(t), kp(0), ki(0), kd(0), integral(0), previousTime(0), previousError(0)
{

}

PID::PID(double t, double p, double i, double d)
	: target(t), kp(p), ki(i), kd(d), integral(0), previousTime(0), previousError(0)
{
}

double PID::Compute(double input)
{
	unsigned long currentTime = millis();
	double deltaTime = (double)(currentTime - previousTime) / 1000;

	double error = target - input;
	integral += error * deltaTime;
	double derivative = (error - previousError) / deltaTime;

	previousError = error;
	previousTime = currentTime;

	return kp * error + ki * integral + kd * derivative;
}
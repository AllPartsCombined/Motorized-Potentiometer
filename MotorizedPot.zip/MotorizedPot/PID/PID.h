/*
  PID.h - Library for creating a PID controller.
  Created by All Parts Combined, 2021.
  Released into the public domain.
*/
#ifndef PID_h
#define PID_h

#include "Arduino.h"

class PID
{
public:
	PID(double t);
	PID(double t, double p, double i, double d);
	double Compute(double input);
	double target;
	double kp;
	double ki;
	double kd;
private:
	double integral;
	double previousError;
	unsigned long previousTime;
};

#endif